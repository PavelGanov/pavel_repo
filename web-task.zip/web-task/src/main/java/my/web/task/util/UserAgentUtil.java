/**
 * 
 */
package my.web.task.util;

import javax.servlet.http.HttpServletRequest;

/**
 * Utility class, contains methods to parse the user-agent header.
 * 
 * @author pganov
 * 
 */
public final class UserAgentUtil {
	/** This constant keeps the list of browsers to recognize */
	private static final String[] DEFAULT_BROWSERS = { "Chrome", "Firefox",
			"Safari", "Opera", "MSIE 10", "MSIE 9", "MSIE 8", "MSIE 7",
			"MSIE 6" };

	/**
	 * Static method, detecting the browser by reading values from a request.
	 * 
	 * @param request
	 *            - the {@link HttpServletRequest} instance.
	 * @return - the detected browser.
	 * @throws NullPointerException
	 *             - if the user-agent header is not available .
	 */
	public static final String getBrowser(HttpServletRequest request)
			throws NullPointerException {
		String userAgent = request.getHeader("user-agent");
		if (userAgent == null) {
			//throw exception if no user-agent available
			throw new NullPointerException("No user-agent header provided");
		}
		String browser = null;
		// iterate the list of recognizable browsers
		for (String browser_id : DEFAULT_BROWSERS) {
			if (userAgent.contains(browser_id)) {
				browser = browser_id;
				//found it, done here
				break;
			}
		}
		return browser;
	}
}
