/**
 * 
 */
package my.web.task.domain;

import java.util.Date;

/**
 * Entry pojo. Each entry represents data of the connection, established between
 * client's browser and the server.
 * 
 * @author pganov
 * 
 */
public class Entry {
	private int id;
	/** When the connection was established */
	private Date c_when;
	/** Which browser was the used */
	private String browser;
	/** The client's ip */
	private String ip;

	/**
	 * Default ctor.
	 */
	public Entry() {
	}

	/**
	 * @param c_when
	 * @param browser
	 * @param ip
	 */
	public Entry(Date c_when, String browser, String ip) {
		super();
		this.c_when = c_when;
		this.browser = browser;
		this.ip = ip;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the c_when
	 */
	public Date getC_when() {
		return c_when;
	}

	/**
	 * @param c_when
	 *            the c_when to set
	 */
	public void setC_when(Date c_when) {
		this.c_when = c_when;
	}

	/**
	 * @return the browser
	 */
	public String getBrowser() {
		return browser;
	}

	/**
	 * @param browser
	 *            the browser to set
	 */
	public void setBrowser(String browser) {
		this.browser = browser;
	}

	/**
	 * @return the ip
	 */
	public String getIp() {
		return ip;
	}

	/**
	 * @param ip
	 *            the ip to set
	 */
	public void setIp(String ip) {
		this.ip = ip;
	}

}
