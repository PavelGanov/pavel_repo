package my.web.task.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import my.web.task.service.EntryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * MVC controller. It handles the listing related requests.
 * 
 * @author pganov
 * 
 */
@Controller
public class ConnectionsListController {
	/** The Entry service */
	@Autowired
	private EntryService entryService;

	/**
	 * Just return the view.
	 * 
	 * @return the "connections-list.jsp" view
	 */
	@RequestMapping("/connections-list")
	public String openView() {
		return "connections-list";
	}

	/**
	 * handles requests for all entries.
	 * 
	 * @param map
	 *            - map to put the entries in.
	 * @return the "connections-list.jsp" view
	 */
	@RequestMapping("/connections-list/all")
	public String listAll(Map<String, Object> map) {
		map.put("entries", entryService.listEntries());
		return "connections-list";
	}

	/**
	 * Handles requests for entries, persisted between two dates.
	 * 
	 * @param from
	 *            - the from date.
	 * @param to
	 *            - the to date.
	 * @param map
	 *            - map to put the entries in.
	 * @return the "connections-list.jsp" view
	 */
	@RequestMapping("/connections-list/range")
	public String listInRange(@RequestParam("from") String from,
			@RequestParam("to") String to, Map<String, Object> map) {
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd.MM.yyyy");
		try {
			Date fromDate = dateFormatter.parse(from);
			Date toDate = dateFormatter.parse(to);
			map.put("entries", entryService.listEntries(fromDate, toDate));
		} catch (ParseException e) {
			e.printStackTrace();
			map.put("message", "Wrong Date format");
		}
		return "connections-list";
	}

}