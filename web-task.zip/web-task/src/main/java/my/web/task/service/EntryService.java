package my.web.task.service;

import java.util.Date;
import java.util.List;

import my.web.task.domain.Entry;

/**
 * The entry service interface. Provides methods to persist and retrieve entry
 * data, using DAO objects.
 * 
 * @author pganov
 * 
 */
public interface EntryService {
	/**
	 * Creates entry and persist it.
	 * 
	 * @param when
	 *            - the date of the entry.
	 * @param browser
	 *            - the browser of the entry.
	 * @param ip
	 *            - the ip of the entry
	 */
	public void createEntry(Date when, String browser, String ip);

	/**
	 * Lists all the entries persisted until now.
	 * 
	 * @return - list of {@link Entry}
	 */
	public List<Entry> listEntries();

	/**
	 * Lists entries which were persisted in certain date range.
	 * 
	 * @param from
	 *            - the start date.
	 * @param to
	 *            - the end date.
	 * @return - the list persisted between <code>from</code> and
	 *         <code>to</code>
	 */
	public List<Entry> listEntries(Date from, Date to);
}
