/**
 * 
 */
package my.web.task.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import my.web.task.dao.EntryDAO;
import my.web.task.domain.Entry;

/**
 * Implementation of {@link EntryService}
 * 
 * @author pganov
 * 
 */
@Service
public class EntryServiceImpl implements EntryService {
	/** The {@link EntryDAO} manager object, used to persist entries */
	@Autowired
	private EntryDAO entryDAO;

	/*
	 * (non-Javadoc)
	 * 
	 * @see my.web.task.service.EntryService#createEntry(java.util.Date,
	 * java.lang.String, java.lang.String)
	 */
	public void createEntry(Date when, String browser, String ip) {
		entryDAO.createAndStoreEntry(when, browser, ip);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see my.web.task.service.EntryService#listEntries()
	 */
	public List<Entry> listEntries() {
		List<Entry> entries = entryDAO.list();
		return entries;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see my.web.task.service.EntryService#listEntries(java.util.Date,
	 * java.util.Date)
	 */
	public List<Entry> listEntries(Date from, Date to) {
		List<Entry> entries = entryDAO.listRange(from, to);
		return entries;
	}

}
