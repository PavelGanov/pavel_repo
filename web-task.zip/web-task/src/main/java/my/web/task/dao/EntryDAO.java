/**
 * 
 */
package my.web.task.dao;

import java.util.Date;
import java.util.List;

import my.web.task.domain.Entry;

/**
 * Interface of the {@link Entry} Data access object.
 * 
 * @author pganov
 * 
 */
public interface EntryDAO {
	/**
	 * Creates an entry object and persist it.
	 * 
	 * @param when
	 *            - c_when field
	 * @param browser
	 *            - browser field
	 * @param ip
	 *            - ip field
	 */
	public void createAndStoreEntry(Date when, String browser, String ip);

	/**
	 * Retrieves all {@link Entry} records
	 * 
	 * @return all the entries.
	 */
	public List<Entry> list();

	/**
	 * Retrieves {@link Entry} records, persisted in a range of dates.
	 * 
	 * @param from
	 *            - the from date
	 * @param to
	 *            - the to date
	 * @return - list of {@link Entry} records.
	 */
	public List<Entry> listRange(Date from, Date to);
}
