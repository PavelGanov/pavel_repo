/**
 * 
 */
package my.web.task.dao;

import java.util.Date;
import java.util.List;

import my.web.task.domain.Entry;
import my.web.task.util.HibernateUtil;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

/**
 * Implementation for the {@link Entry} data access object
 * 
 * @author pganov
 * 
 */
@Repository
public class EntryDAOImpl implements EntryDAO {
	/*
	 * (non-Javadoc)
	 * 
	 * @see my.web.task.dao.EntryDAO#createAndStoreEntry(java.util.Date,
	 * java.lang.String, java.lang.String)
	 */
	public void createAndStoreEntry(Date when, String browser, String ip) {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();

		// create entry
		Entry entry = new Entry(when, browser, ip);

		// store it
		session.save(entry);
		session.getTransaction().commit();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see my.web.task.dao.EntryDAO#list()
	 */
	@SuppressWarnings("unchecked")
	public List<Entry> list() {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();

		// SELECT all entries
		String hql = "FROM Entry E";
		Query query = session.createQuery(hql);
		List<Entry> result = query.list();

		session.getTransaction().commit();
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see my.web.task.dao.EntryDAO#listRange(java.util.Date, java.util.Date)
	 */
	@SuppressWarnings("unchecked")
	public List<Entry> listRange(Date from, Date to) {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
		// SELECT entries between from and to
		String hql = "FROM Entry E WHERE E.c_when > :from AND E.c_when < :to";
		Query query = session.createQuery(hql);
		query.setParameter("from", from);
		query.setParameter("to", to);
		List<Entry> result = query.list();

		session.getTransaction().commit();
		return result;
	}
}
