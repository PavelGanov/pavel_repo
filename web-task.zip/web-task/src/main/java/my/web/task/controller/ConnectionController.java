/**
 * 
 */
package my.web.task.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import my.web.task.service.EntryService;
import my.web.task.util.UserAgentUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * MVC controller. It handles the connection related requests.
 * 
 * @author pganov
 */
@Controller
public class ConnectionController {
	/** The Entry service */
	@Autowired
	private EntryService entryService;

	/**
	 * Handles connection. For each connection, create entry and persist it.
	 * 
	 * @param request
	 *            - the request from where the <b>ip</b> and <b>browser</b> of
	 *            the clients are provided.
	 * @return the "connection.jsp" view with the details for the connection
	 */
	@RequestMapping(value = "/connection")
	public ModelAndView addEntry(HttpServletRequest request) {
		Map<String, Object> model = new HashMap<String, Object>();
		ModelAndView mav = new ModelAndView("connection");
		// Gather the date to persist
		Date now = new Date();
		String browser = UserAgentUtil.getBrowser(request);
		String ip = request.getRemoteAddr();

		entryService.createEntry(now, browser, ip);

		// fill the model and add it to the view
		model.put("date", now);
		model.put("browser", browser);
		model.put("ip", ip);
		mav.addAllObjects(model);
		return mav;
	}
}
